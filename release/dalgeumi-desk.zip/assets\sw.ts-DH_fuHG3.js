chrome.runtime.onInstalled.addListener(()=>{console.log("dalgeumi-desk installed")});
//# sourceMappingURL=sw.ts-DH_fuHG3.js.map
